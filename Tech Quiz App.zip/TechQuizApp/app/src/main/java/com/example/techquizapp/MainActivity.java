package com.example.techquizapp;

import static com.example.techquizapp.SplashActivity.list;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    CountDownTimer countDownTimer;
    int timerValue=20;
    ProgressBar progressBar;
    List<ModelClass> allQuestionsList;
    ModelClass currentQuestion;
    int currentIndex = 0;
    private boolean isAnswerSelected = false;

    TextView card_question,optiona,optionb,optionc,optiond;
    CardView cardOA,cardOB,cardOC,cardOD;
    int correctCount=0;
    int wrongCount=0;
    LinearLayout nextBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Hooks();
        // Initialize list
        allQuestionsList = SplashActivity.list;
        Collections.shuffle(allQuestionsList); // For random question show
        currentQuestion = allQuestionsList.get(currentIndex);


        // Progress Bar

        progressBar.setMax(timerValue); // Set the maximum value of the progress bar to the timer duration

        // Initialize and start the CountDownTimer with the correct duration
        countDownTimer = new CountDownTimer(timerValue * 3000, 3000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerValue = (int) (millisUntilFinished / 3000);
                progressBar.setProgress(timerValue);
            }

            @Override
            public void onFinish() {
                // Timer has finished, you can handle what should happen here
                Log.d("MainActivity", "onFinish: Timer has finished!");
                Dialog dialog = new Dialog(MainActivity.this,R.style.Dialoge);
                dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
                dialog.setContentView(R.layout.time_out_dialog);
                dialog.findViewById(R.id.btn_tryAgain).setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Log.d("MainActivity", "onClick: Try Again button clicked!");
                        Intent intent = new Intent(MainActivity.this, SplashActivity.class);
                        startActivity(intent);
                    }
                });
                dialog.show();
            }
        }.start();
        // Set data for the first question
        SetAllData();
        nextBtn.setClickable(false);
    }

    private void SetAllData() {
        card_question.setText(currentQuestion.getQuestion());
        optiona.setText(currentQuestion.getoA());
        optionb.setText(currentQuestion.getoB());
        optionc.setText(currentQuestion.getoC());
        optiond.setText(currentQuestion.getoD());
    }

    private void Hooks() {
        progressBar = findViewById(R.id.quiz_timer);
        card_question=findViewById(R.id.card_question);
        optiona=findViewById(R.id.optiona);
        optionb=findViewById(R.id.optionb);
        optionc=findViewById(R.id.optionc);
        optiond=findViewById(R.id.optiond);

        cardOA=findViewById(R.id.cardA);
        cardOB=findViewById(R.id.cardB);
        cardOC=findViewById(R.id.cardC);
        cardOD=findViewById(R.id.cardD);

        nextBtn=findViewById(R.id.nextBtn);



    }
    public void Correct(CardView cardView) {
        cardView.setCardBackgroundColor(getResources().getColor(R.color.green));
        correctCount++; // Increment the correct count

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Increment currentIndex to move to the next question
                currentIndex++;

                // Check if there are more questions left
                if (currentIndex < allQuestionsList.size()) {
                    // Get the next question from the list
                    currentQuestion = allQuestionsList.get(currentIndex);

                    // Update the UI with the new question
                    SetAllData();
                    enableButton();
                    isAnswerSelected = false;

                    // Reset the answer option card background colors
                    resetColor();
                } else {
                    // No more questions, show the "GameWon" screen
                    GameWon();
                }
            }
        });
    }

    public void Wrong(CardView cardOA) {
        cardOA.setCardBackgroundColor(getResources().getColor(R.color.red2));
        wrongCount++; // Increment the wrong count

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Increment currentIndex to move to the next question
                currentIndex++;

                // Check if there are more questions left
                if (currentIndex < allQuestionsList.size()) {
                    // Get the next question from the list
                    currentQuestion = allQuestionsList.get(currentIndex);

                    // Update the UI with the new question
                    SetAllData();
                    enableButton();
                    isAnswerSelected = false;

                    // Reset the answer option card background colors
                    resetColor();

                } else {
                    // No more questions, show the "GameWon" screen
                    GameWon();
                }
            }
        });
    }

    private void GameWon() {
        Intent intent =new Intent(MainActivity.this,WonActivity.class);
        intent.putExtra("correct",correctCount);
        intent.putExtra("wrong",wrongCount);
        startActivity(intent);
    }
    public void enableButton() {
        cardOA.setClickable(true);
        cardOB.setClickable(true);
        cardOC.setClickable(true);
        cardOD.setClickable(true);
    }

    public void disableButton() {
        cardOA.setClickable(false);
        cardOB.setClickable(false);
        cardOC.setClickable(false);
        cardOD.setClickable(false);
    }
    public void resetColor(){
        cardOA.setCardBackgroundColor(getResources().getColor(R.color.white));
        cardOB.setCardBackgroundColor(getResources().getColor(R.color.white));
        cardOC.setCardBackgroundColor(getResources().getColor(R.color.white));
        cardOD.setCardBackgroundColor(getResources().getColor(R.color.white));
    }

    public void optionaClick(View view) {
        nextBtn.setClickable(true);
        // Disable the option buttons when an option is clicked
        if (!isAnswerSelected) {
            isAnswerSelected = true;
            disableButton();

            if (currentQuestion.getoA().equals(currentQuestion.getAns())) {
                cardOA.setCardBackgroundColor(getResources().getColor(R.color.green));
                if (currentIndex < list.size() - 1) {
                    Correct(cardOA);
                } else {
                    GameWon();
                }
            } else {
                Wrong(cardOA);
            }
        }
    }

    public void optionbClick(View view) {
        nextBtn.setClickable(true);
        // Disable the option buttons when an option is clicked
        if (!isAnswerSelected) {
            isAnswerSelected = true;
            disableButton();

            if (currentQuestion.getoB().equals(currentQuestion.getAns())) {
                cardOB.setCardBackgroundColor(getResources().getColor(R.color.green));
                if (currentIndex < list.size() - 1) {
                    Correct(cardOB);
                } else {
                    GameWon();
                }
            } else {
                Wrong(cardOB);
            }
        }
    }

    public void optioncClick(View view) {
        nextBtn.setClickable(true);
        if (!isAnswerSelected) {
            isAnswerSelected = true;
            disableButton();
            if (currentQuestion.getoC().equals(currentQuestion.getAns())) {
                cardOC.setCardBackgroundColor(getResources().getColor(R.color.green));
                if (currentIndex < list.size() - 1) {
                    Correct(cardOC);

                } else {
                    GameWon();
                }
            } else {
                Wrong(cardOC);
            }
        }
    }

    public void optiondClick(View view) {
        nextBtn.setClickable(true);
        if (!isAnswerSelected) {
            isAnswerSelected = true;
            disableButton();
            if (currentQuestion.getoD().equals(currentQuestion.getAns())) {
                cardOD.setCardBackgroundColor(getResources().getColor(R.color.green));
                if (currentIndex < list.size() - 1) {
                    Correct(cardOD);

                } else {
                    GameWon();
                }
            } else {
                Wrong(cardOD);
            }
        }
    }
}



//import androidx.appcompat.app.AppCompatActivity;
//
//        import android.app.Dialog;
//        import android.content.Intent;
//        import android.os.Bundle;
//        import android.os.CountDownTimer;
//        import android.view.View;
//        import android.view.WindowManager;
//        import android.widget.ProgressBar;
//
//public class MainActivity extends AppCompatActivity {
//    CountDownTimer countDownTimer;
//    int timerValue=20;
//    ProgressBar progressBar;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//        //Progress Bar
//        progressBar=findViewById(R.id.quiz_timer);
//        countDownTimer =new CountDownTimer(2000,1000) {
//            @Override
//            public void onTick(long millisUntilFinished) {
//                timerValue=timerValue-1;
//                progressBar.setProgress(timerValue);
//
//            }
//
//            @Override
//            public void onFinish() {
//                // Timer has finished, you can handle what should happen here
//                Dialog dialog = new Dialog(MainActivity.this,R.style.Dialoge);
//                dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND);
//                dialog.setContentView(R.layout.time_out_dialog);
//                dialog.findViewById(R.id.btn_tryAgain).setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View v) {
//                        Intent intent=new Intent(MainActivity.this,SplashActivity.class);
//                        startActivity(intent);
//                    }
//                });
//                dialog.show();
//
//            }
//        }.start();
//    }
//}




