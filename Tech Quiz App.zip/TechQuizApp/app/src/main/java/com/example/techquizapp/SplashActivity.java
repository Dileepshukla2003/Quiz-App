package com.example.techquizapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;

public class SplashActivity extends AppCompatActivity {
    public static  ArrayList<ModelClass> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        getSupportActionBar().hide();

        list =new ArrayList<>();
        list.add(new ModelClass("awasasas1","a","b","c","d","a"));
        list.add(new ModelClass("awasasas2","a","b","c","d","a"));
        list.add(new ModelClass("awasasas3","a","b","c","d","a"));
        list.add(new ModelClass("awasasas4","a","b","c","d","a"));
        list.add(new ModelClass("awasasas5","a","b","c","d","a"));
        list.add(new ModelClass("awasasas6","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas5","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas","a","b","c","d","a"));
        list.add(new ModelClass("awasasas2","a","b","c","d","a"));
        list.add(new ModelClass("awasasas20","a","b","c","d","a"));


        Thread thread = new Thread(){
            public void run(){
                try{
                    sleep(4000);

                }
                catch(Exception e){
                    e.printStackTrace();

                }
                finally{
                    Intent intent = new Intent(SplashActivity.this , MainActivity.class);
                    startActivity(intent);
                    finish();

                }
            }

        };thread.start();
    }
}